# Thorpy - Yann Thorimbert - yann.thorimbert@gmail.com

ThorPy is a free GUI library intended for use with pygame. More informations on http://www.thorpy.org.

